
import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { Toaster } from 'sonner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import LeistungenPage from './pages/LeistungenPage';
import EinsatzgebieteDetailPage from './pages/EinsatzgebieteDetailPage';
import UberUnsPage from './pages/UberUnsPage';
import KontaktPage from './pages/KontaktPage';

// Category Pages
import FuersorgeDetailPage from './pages/FuersorgeDetailPage';
import FamilieDetailPage from './pages/FamilieDetailPage';
import BegleitserviceDetailPage from './pages/BegleitserviceDetailPage';
import BaudienstleistungenDetailPage from './pages/BaudienstleistungenDetailPage';
import EventDetailPage from './pages/EventDetailPage';
import AltersBarrierefreiesWohnenDetailPage from './pages/AltersBarrierefreiesWohnenDetailPage';

// Dynamic Subcategory Page
import SubcategoryDetailPage from './pages/SubcategoryDetailPage';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Toaster position="top-right" richColors />
      <Routes>
        <Route path="/" element={<HomePage />} />
        
        {/* Leistungen Routes */}
        <Route path="/leistungen" element={<LeistungenPage />} />
        
        <Route path="/leistungen/fuersorge" element={<FuersorgeDetailPage />} />
        <Route path="/leistungen/familie" element={<FamilieDetailPage />} />
        <Route path="/leistungen/begleitservice" element={<BegleitserviceDetailPage />} />
        <Route path="/leistungen/baudienstleistungen" element={<BaudienstleistungenDetailPage />} />
        <Route path="/leistungen/event" element={<EventDetailPage />} />
        <Route path="/leistungen/alters-barrierefreies-wohnen" element={<AltersBarrierefreiesWohnenDetailPage />} />
        
        {/* Dynamic Subcategory Route */}
        <Route path="/leistungen/:categorySlug/:subcategorySlug" element={<SubcategoryDetailPage />} />
        
        {/* Other Pages */}
        <Route path="/einsatzgebiete" element={<EinsatzgebieteDetailPage />} />
        <Route path="/uber-uns" element={<UberUnsPage />} />
        <Route path="/kontakt" element={<KontaktPage />} />
        
        {/* Fallback */}
        <Route path="*" element={<HomePage />} />
      </Routes>
    </Router>
  );
}

export default App;
