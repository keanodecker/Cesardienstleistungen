
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';

const services = [
  {
    title: 'Fürsorge für Jung & Alt',
    items: ['Regelmäßiger Besuch & nach dem Rechten schauen', 'Erledigen von Außen- & Innen-Anfälligkeiten', 'Termine', 'Reinigungen & Besorgungen']
  },
  {
    title: 'Familie',
    items: ['Erbschaftsabwicklung & Übernahme von Erbe', 'Professionelle Begleitung im Trauerfall & Beerdigungsorganisation', 'Besuche bei fernen Verwandten']
  },
  {
    title: 'Begleitservice',
    items: ['Ausflüge & Tagesausflüge', 'Urlaubsbegleitung', 'inkl. Fahrservice']
  },
  {
    title: 'Baudienstleistungen',
    items: ['Von Entkernung bis Wohn-/Mietbereitschaft', 'Sanierungen', 'Bodenbeläge & Streichen', 'Treppen, Türen & Möbel-Projekte']
  },
  {
    title: 'Event',
    items: ['Auf- & Abbau', 'Bedienung & Thekenpersonal', 'Planung']
  },
  {
    title: 'Alters- & barrierefreies Wohnen',
    items: ['Bäder', 'Stufen', 'Treppen', 'Rollstuhlgerecht', 'Terrassen']
  },
  {
    title: 'Umzüge & Entrümpelung',
    items: ['Umzüge', 'Entrümpelung', 'Eilräumung']
  }
];

function LeistungenDropdown({ isOpen }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 10, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 10, scale: 0.95 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          className="absolute left-1/2 -translate-x-1/2 top-full mt-4 w-[800px] bg-white shadow-2xl rounded-2xl border border-border/50 z-50 overflow-hidden"
        >
          <div className="p-8">
            <div className="grid grid-cols-2 gap-x-12 gap-y-8">
              {services.map((service, index) => (
                <div key={index} className="space-y-3">
                  <Link 
                    to="/leistungen" 
                    className="font-semibold text-primary hover:text-primary/80 transition-colors block"
                  >
                    {service.title}
                  </Link>
                  <ul className="space-y-2">
                    {service.items.map((item, itemIndex) => (
                      <li key={itemIndex} className="text-sm text-muted-foreground leading-snug flex items-start gap-2">
                        <span className="w-1 h-1 rounded-full bg-primary/40 mt-2 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <div className="mt-8 pt-6 border-t border-border/50 text-center">
              <Link 
                to="/leistungen"
                className="text-sm font-medium text-primary hover:underline"
              >
                Alle Leistungen im Detail ansehen &rarr;
              </Link>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default LeistungenDropdown;
